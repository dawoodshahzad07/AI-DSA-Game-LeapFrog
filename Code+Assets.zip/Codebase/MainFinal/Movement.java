package MainFinal;

import javax.swing.*;
import java.io.File;
import java.util.Stack;

import jaco.mp3.player.MP3Player;

public class Movement {

    MP3Player mp3 = new MP3Player();
    Map_2D m2d = new Map_2D();
    public static int fPosX = 5, fPosY = 0;
    public static int movePx = 200, movePy = 150;
    public static String jumpsfx = Game.Directory+":\\LeapFrog\\GameAssets\\SFX\\jump.mp3";
    public static String winsfx = Game.Directory+":\\LeapFrog\\GameAssets\\SFX\\levelclear.mp3";
    public static String hintsfx = Game.Directory+":\\LeapFrog\\GameAssets\\SFX\\coin.mp3";
    public static String bumpsfx = Game.Directory+":\\LeapFrog\\GameAssets\\SFX\\bump.mp3";

    public int totalMoves = 0, totalScore = 999;

    //int movePy = 100;

    void moveRight(JLabel player){


        if(!canMove() || !canMove("RIGHT")) {
            return;
        }
        else if(fPosY == 7){
            System.out.println("cantmov1");
            return;}

        m2d.Pgrid[fPosX][fPosY] = 0;

        fPosY++;

        m2d.Pgrid[fPosX][fPosY] = 1;

        System.out.println("MOVING RIGHT");
        MP3Player sfx = new MP3Player(new File(jumpsfx));
        sfx.play();
        totalMoves++;
        totalScore-=50;
        player.setIcon(new ImageIcon(Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\Frog\\frogR.png"));
        player.setLocation(player.getX() + movePx, player.getY());
    }


    void moveLeft(JLabel player){

        if(!canMove() || !canMove("LEFT")) {
            return;
        }
        if(fPosY == 0) return;

        m2d.Pgrid[fPosX][fPosY] = 0;
        fPosY--;
        m2d.Pgrid[fPosX][fPosY] = 1;

        System.out.println("MOVING LEFT");
        MP3Player sfx = new MP3Player(new File(jumpsfx));
        sfx.play();
        totalMoves++;
        totalScore-=50;
        player.setIcon(new ImageIcon(Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\Frog\\frogL.png"));
        player.setLocation(player.getX() - movePx, player.getY());
    }

    void moveUp(JLabel player){

        if(!canMove() || !canMove("UP"))
            return;


        m2d.Pgrid[fPosX][fPosY] = 0;
        fPosX--;
        m2d.Pgrid[fPosX][fPosY] = 1;

        System.out.println("MOVING UP");
        MP3Player sfx = new MP3Player(new File(jumpsfx));
        sfx.play();
        totalMoves++;
        totalScore-=50;
        player.setIcon(new ImageIcon(Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\Frog\\frogU.png"));
        player.setLocation(player.getX(), player.getY() - movePy);
    }


    void moveDown(JLabel player){

        if(!canMove() || !canMove("DOWN"))
            return;

        if(fPosX == 5) return;

        m2d.Pgrid[fPosX][fPosY] = 0;
        fPosX++;
        m2d.Pgrid[fPosX][fPosY] = 1;

        System.out.println("MOVING DOWN");
        MP3Player sfx = new MP3Player(new File(jumpsfx));
        sfx.play();
        totalMoves++;
        totalScore-=50;
        player.setIcon(new ImageIcon(Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\Frog\\frogD.png"));
        player.setLocation(player.getX(), player.getY()+ movePy);

    }

    boolean canMove(){



        //if(fPosX == 0) return false; //lock into place when game won

        if(fPosX > 5 || fPosY > 7 || fPosX < 0 || fPosY < 0)
            return false;


        //System.out.println("cant move there!");
        return true;
    }

    boolean canMove(String place){ //can Move function for obstacles

        boolean clear = true;

        if(place.equals("UP")){

            //If an exception occurs,
            //it means that there is no way to move to the next box,
            //so we make it not safe to move on to, same logic in this whole function)
            try {
                if (m2d.Ogrid[fPosX - 1][fPosY] == 1)
                    clear = false;
            }catch(Exception e){
                System.out.println("U_Except");
                clear = false;
            }
        }
        else if (place.equals("DOWN")){

            try {
                if(m2d.Ogrid[fPosX+1][fPosY] == 1 || fPosX == Map_2D.num_Vertical_boxes - 1)
                    clear = false;
            }catch(Exception e){
                System.out.println("D_Except");
                clear = false;
            }
        }
        else if (place.equals("RIGHT")){

            try {
                if(m2d.Ogrid[fPosX][fPosY+1] == 1 || fPosY == Map_2D.num_Horizontal_boxes - 1)
                    clear = false;
            }catch(Exception e){
                System.out.println("R_Except");
                clear = false;
            }
        }
        else if (place.equals("LEFT")){

            try {
                if(m2d.Ogrid[fPosX][fPosY-1] == 1 || fPosY == 0)
                    clear = false;
            }catch(Exception e){
                System.out.println("L_Except");
                clear = false;
            }
        }


        if(!clear) {
            System.out.println("Cant go there!");
        }

        return clear;
    }

    boolean hasWon(JLabel player, int stage){

        if(stage==Levels.LEVEL_TRAINING){
            if (fPosX == 1 && fPosY == 4) {
                MP3Player sfx = new MP3Player(new File(winsfx));
                sfx.play();
                return true;
            }

        }
        else if(stage==Levels.LEVEL_1) {
            if (fPosX == 1 && fPosY == 7) {
                MP3Player sfx = new MP3Player(new File(winsfx));
                sfx.play();
                return true;
            }
        }
        else if(stage==Levels.LEVEL_2) {
            if (fPosX == 2 && fPosY == 3) {
                MP3Player sfx = new MP3Player(new File(winsfx));
                sfx.play();
                return true;
            }
        }

        return false;
    }


    void showPath(Stack<Cell> s){

        Stack<Cell> temp = s;

        while(!temp.isEmpty()){

            Cell c = temp.pop();
            System.out.println("(" + c.row + ", " + c.col + ") ");
        }
    }
}
