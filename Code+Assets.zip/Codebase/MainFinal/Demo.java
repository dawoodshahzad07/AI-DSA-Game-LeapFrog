package MainFinal;

public class Demo {
    public static void main(String[] args) {

        //MainMenu m1 = new MainMenu();

        Game game=new Game();
        //this.add(m1.panel);

    }
}
