package MainFinal;

import java.util.*;

class Cell {
    int row;
    int col;
    int gScore; // Cost to reach this cell from the start
    int hScore; // Heuristic cost to reach the goal from this cell
    int fScore; // Total cost (gScore + hScore)
    Cell parent; // Parent cell in the path

    public Cell(int row, int col, int gScore, int hScore, Cell parent) {
        this.row = row;
        this.col = col;
        this.gScore = gScore;
        this.hScore = hScore;
        this.fScore = gScore + hScore;
        this.parent = parent;
    }
}

public class AStarSearch {

    public static int calculateDistance(Cell a, Cell b) {
        return Math.abs(a.row - b.row) + Math.abs(a.col - b.col);
    }

    //Checks if the block is in the bounds
    public static boolean isValidCell(int row, int col, int numRows, int numCols) {
        return row >= 0 && row < numRows && col >= 0 && col < numCols;
    }

    //Searching algo
    public static List<Cell> aStarSearch(int[][] grid, Cell start, Cell goal) {
        int numRows = grid.length;
        int numCols = grid[0].length;

        //Initialization
        boolean[][] visited = new boolean[numRows][numCols];
        PriorityQueue<Cell> openSet = new PriorityQueue<>(Comparator.comparingInt(a -> a.fScore));
        openSet.add(start);


        while (!openSet.isEmpty()) {
            Cell current = openSet.poll();

            if (current.row == goal.row && current.col == goal.col) {
                List<Cell> path = new ArrayList<>();
                while (current != null) {
                    path.add(current);
                    current = current.parent;
                }
                return path;
            }

            visited[current.row][current.col] = true;

            int[][] neighbors = { {-1, 0}, {1, 0}, {0, -1}, {0, 1} };
            for (int[] neighbor : neighbors) {
                int newRow = current.row + neighbor[0];
                int newCol = current.col + neighbor[1];

                if (isValidCell(newRow, newCol, numRows, numCols) && grid[newRow][newCol] == 0 && !visited[newRow][newCol]) {
                    int newGScore = current.gScore + 1;
                    int newHScore = calculateDistance(new Cell(newRow, newCol, 0, 0, null), goal);

                    Cell neighborCell = new Cell(newRow, newCol, newGScore, newHScore, current);
                    openSet.add(neighborCell);
                }
            }
        }

        return new ArrayList<>(); // No path found
    }

    public Stack<Cell> calcPath(int[][] grid, int spawnX, int spawnY, int goalX, int goalY){

        Stack<Cell> shortPath = new Stack<Cell>();

        int numRows = grid.length;
        int numCols = grid[0].length;

        Cell start = new Cell(spawnX, spawnY, 0, 0, null);
        Cell goal = new Cell(goalX, goalY, 0, 0, null);

        List<Cell> path = aStarSearch(grid, start, goal);

        if (!path.isEmpty()) {
            for (Cell cell : path) {

                shortPath.add(cell);
                //System.out.println("(" + cell.row + ", " + cell.col + ") ");
            }
        } else {
            System.out.println("No path found.");
        }

        /*while(!shortPath.isEmpty()){

            Cell c = shortPath.pop();
            System.out.println("(" + c.row + ", " + c.col + ") ");
        }*/

        return shortPath;

    }
    /*public static void main(String[] args) {

        Stack<Cell> shortPath = new Stack<Cell>();

        int[][] grid = {
                {1, 1, 1, 1, 1, 1, 1, 1},
                {1, 0, 0, 0, 0, 0, 0, 0},
                {1, 1, 0, 0, 0, 0, 0, 1},
                {1, 1, 0, 0, 0, 1, 0, 1},
                {1, 0, 0, 0, 0, 1, 1, 0},
                {1, 1, 1, 0, 1, 1, 1, 1}
        };

        int numRows = grid.length;
        int numCols = grid[0].length;

        Cell start = new Cell(5, 3, 0, 0, null);
        Cell goal = new Cell(1, 7, 0, 0, null);

        List<Cell> path = aStarSearch(grid, start, goal);

        if (!path.isEmpty()) {
            for (Cell cell : path) {

                shortPath.add(cell);
                //System.out.println("(" + cell.row + ", " + cell.col + ") ");
            }
        } else {
            System.out.println("No path found.");
        }

        while(!shortPath.isEmpty()){

            Cell c = shortPath.pop();
            System.out.println("(" + c.row + ", " + c.col + ") ");
        }
    }*/
}