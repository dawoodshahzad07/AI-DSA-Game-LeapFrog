package MainFinal;

import javax.swing.*;
import java.awt.*;

/////////     Functions
//////
///   void levelSelectHUD(int xPos, int yPos)
//    void updateHUD(int score, int moves)
///   void DPadUpdate(Movement move)
////
//////

public class DPad {
    static String Directory = Game.Directory;

    private String dpad_bg = Directory + ":\\LeapFrog\\GameAssets\\GFX\\Interactive\\dpadOFF.png";
    private String right_on = Directory + ":\\LeapFrog\\GameAssets\\GFX\\Interactive\\dpad_R_on.png";
    private String left_on = Directory + ":\\LeapFrog\\GameAssets\\GFX\\Interactive\\dpad_L_on.png";
    private String up_on = Directory + ":\\LeapFrog\\GameAssets\\GFX\\Interactive\\dpad_U_on.png";
    private String down_on = Directory + ":\\LeapFrog\\GameAssets\\GFX\\Interactive\\dpad_D_on.png";


    JLabel back, right, left, up, down, scoreDisplay, moveDisplay;

    //private int xPos = 1200, yPos = 100, width = 250, height = 250;
    private int xPos = 1585, yPos = 115, width = 250, height = 250;

    DPad(){

        back = new JLabel();
        back.setIcon(new ImageIcon(dpad_bg));
        back.setBounds(xPos, yPos, width, height);
        back.setVisible(true);

        right = new JLabel();
        right.setIcon(new ImageIcon(right_on));
        right.setBounds(xPos, yPos, width, height);
        right.setVisible(true);

        left = new JLabel();
        left.setIcon(new ImageIcon(left_on));
        left.setBounds(xPos, yPos, width, height);
        left.setVisible(true);

        up = new JLabel();
        up.setIcon(new ImageIcon(up_on));
        up.setBounds(xPos, yPos, width, height);
        up.setVisible(true);

        down = new JLabel();
        down.setIcon(new ImageIcon(down_on));
        down.setBounds(xPos, yPos, width, height);
        down.setVisible(true);

        scoreDisplay = new JLabel();
        moveDisplay = new JLabel();

    }

    void levelSelectHUD(int xPos, int yPos){

        int level = -1;

        if(xPos == 5 && yPos == 3)
            level = 0;
        else if(xPos == 5 && yPos == 4)
            level = 1;
        else if(xPos == 3 && yPos == 4)
            level = 2;
        else if(xPos == 3 && yPos == 3)
            level = 3;

        if(level == -1)
            this.moveDisplay.setText("");
        else
            this.moveDisplay.setText(""+level);
        this.moveDisplay.setBounds(1670, 660, 180, 100);
        this.moveDisplay.setFont(new Font("Pixeboy", 0, 70));
        this.moveDisplay.setForeground(new Color(0, 0, 0));
        this.moveDisplay.setOpaque(false);

    }
    void updateHUD(int score, int moves){

        if(score < 0)
            this.scoreDisplay.setText(""+0);
        else
            this.scoreDisplay.setText(""+score);
        this.scoreDisplay.setBounds(1625, 515, 180, 100);
        this.scoreDisplay.setFont(new Font("Pixeboy", 0, 70));
        this.scoreDisplay.setForeground(new Color(0, 0, 0));
        this.scoreDisplay.setOpaque(false);

        this.moveDisplay.setText(""+moves);
        this.moveDisplay.setBounds(1660, 780, 180, 100);
        this.moveDisplay.setFont(new Font("Pixeboy", 0, 70));
        this.moveDisplay.setForeground(new Color(0, 0, 0));
        this.moveDisplay.setOpaque(false);
    }

    void DPadUpdate(Movement move){

        this.up.setVisible(move.canMove("UP"));
        this.down.setVisible(move.canMove("DOWN"));
        this.left.setVisible(move.canMove("LEFT"));
        this.right.setVisible(move.canMove("RIGHT"));

    }

}
