package MainFinal;

import javax.swing.*;
import java.util.Stack;

public class Map1 {
    JPanel jPanel;
    JLayeredPane layer;
    JLabel map1, mapOver, goal;

    JLabel lilyPads[][];
    JLabel hints[][];

    String b_address= Game.Directory+ ":\\LeapFrog\\GameAssets\\GFX\\Background\\Level11.jpg";
    String bOver_address= Game.Directory+ ":\\LeapFrog\\GameAssets\\GFX\\Background\\Level1Over.png";
    String goalAddr= Game.Directory+ ":\\LeapFrog\\GameAssets\\GFX\\Blocks\\coin.gif";

    Movement movement=new Movement();
    Frog frog=new Frog();
    DPad dPad=new DPad();

    public static final int SCREEN_WIDTH=1850,SCREEN_HEIGHT=900;

    public int goalX = 1, goalY = 7;
    public int moves = 0, score = 999;
    int Ogrid1[][] ={{1, 1, 1, 1, 1, 1, 1, 1},
                    {1, 0, 0, 0, 0, 0, 0, 0},
                    {1, 0, 0, 0, 0, 0, 0, 1},
                    {1, 1, 0, 0, 0, 0, 0, 1},
                    {1, 0, 0, 0, 0, 1, 1, 0},
                    {1, 1, 1, 0, 1, 1, 1, 1}
    };

    Map1(){

        //setting the current obstacle grid to this map's obstacle grid
        movement.m2d.Ogrid = this.Ogrid1;

        labelMap1();
        DPadInitialize();

        jLayer();
        jPanel();

    }

    //Initializes background
    public void labelMap1(){
        map1=new JLabel();
        map1.setBounds(0,0,SCREEN_WIDTH,SCREEN_HEIGHT);
        map1.setIcon(new ImageIcon(b_address));
        map1.setVisible(true);

        mapOver=new JLabel();
        mapOver.setBounds(0,0,SCREEN_WIDTH,SCREEN_HEIGHT);
        mapOver.setIcon(new ImageIcon(bOver_address));
        mapOver.setVisible(true);

        goal=new JLabel();
        goal.setBounds(7*200,80,250,250);
        goal.setIcon(new ImageIcon(goalAddr));
        goal.setVisible(true);
    }

    //Compiles the different backgroubnd layers into one panel
    public void jPanel(){
        jPanel=new JPanel();
        jPanel.setBounds(0,0,SCREEN_WIDTH,SCREEN_HEIGHT);
        jPanel.setLayout(null);
        jPanel.add(layer);
        jPanel.setVisible(false);
    }

    //Manages the layering
    public void jLayer(){
        layer=new JLayeredPane();
        layer.setBounds(0,0,SCREEN_WIDTH,SCREEN_HEIGHT);
        layer.add(map1,new Integer(1));
        layer.add(frog.frog,new Integer(4));
        lilySpawn(layer);

        layer.add(goal,new Integer(7));

        layer.add(mapOver,new Integer(5));
        layer.add(dPad.scoreDisplay,new Integer(5));
        layer.add(dPad.moveDisplay,new Integer(5));

        layer.add(dPad.back,new Integer(5));
        layer.add(dPad.up,new Integer(6));
        layer.add(dPad.down,new Integer(6));
        layer.add(dPad.right,new Integer(6));
        layer.add(dPad.left,new Integer(6));
    }


    //Spawns lilypads where obstacles are found
    public void lilySpawn(JLayeredPane layer) {

        lilyPads = new JLabel[Map_2D.num_Horizontal_boxes][Map_2D.num_Vertical_boxes+2];
        hints = new JLabel[Map_2D.num_Horizontal_boxes][Map_2D.num_Vertical_boxes+2];

        //Iterate through the entire grid
        for (int i = 0; i < Map_2D.num_Vertical_boxes; i++) {

            for (int j = 0; j < Map_2D.num_Horizontal_boxes; j++) {

                //If n obstacle is found
                try {
                    //dont do anythig
                    if (this.Ogrid1[i][j] == 1)
                        continue;
                    else{
                    //If no obstacle is found, display a lilyPad
                        JLabel pad = new JLabel();
                        JLabel hint = new JLabel();

                        pad.setIcon(new ImageIcon(Game.Directory + ":\\LeapFrog\\GameAssets\\GFX\\Blocks\\L1d.png"));
                        pad.setBounds(j * 200, i * (150 - 2), 200, 156);
                        pad.setVisible(true);
                        lilyPads[i][j] = pad;
                        layer.add(pad, new Integer(3));

                        hint.setIcon(new ImageIcon(Game.Directory + ":\\LeapFrog\\GameAssets\\GFX\\Interactive\\hint.png"));
                        hint.setBounds(j * 200, i * (150 - 2), 200, 156);
                        hint.setVisible(false);
                        hints[i][j] = hint;
                        layer.add(hint, new Integer(4));


                    }
                }catch(Exception e){

                }
            }
        }
    }

    //Removes the glowy hint path
    public void unglowPath(){

        for (int i = 0; i < Map_2D.num_Vertical_boxes; i++) {
            for (int j = 0; j < Map_2D.num_Horizontal_boxes; j++)
                try{
                    hints[i][j].setVisible(false);
                }catch(Exception e){ }
        }


    }

    //Glows the hint path
    public void glowPath(Stack<Cell> path){

        //first  unglow if theres already a hint used
        unglowPath();

        Cell temp;
        Stack<Cell> Cpath = path;


        //Back track your way to the spawn
        while (!Cpath.isEmpty()) {

            temp = Cpath.pop();
            System.out.println(temp.row +" "+ temp.col);

            hints[temp.row][temp.col].setVisible(true);
        }

        System.out.println("path empty");
    }

    //Enable the visited blocks
    public void enablePads(int fPosX, int fPosY){

        lilyPads[fPosX][fPosY].setIcon(new ImageIcon(Game.Directory + ":\\LeapFrog\\GameAssets\\GFX\\Blocks\\L1e.png"));
    }

    //marjs all lilypads on screen as unvisited
    public void clearPads(){

        for (int i = 0; i < Map_2D.num_Vertical_boxes; i++) {
            for (int j = 0; j < Map_2D.num_Horizontal_boxes; j++)
                try {
                    hints[i][j].setVisible(false);
                    lilyPads[i][j].setIcon(new ImageIcon(Game.Directory + ":\\LeapFrog\\GameAssets\\GFX\\Blocks\\L1d.png"));
                }catch(Exception e){}
        }
    }


    //Initializes the moaves for the HUD
    public void initMoves(Movement movement){
        movement.totalMoves = moves;
        movement.totalScore = score;
    }


    //initializes the DPAD for this level
    void DPadInitialize(){
        dPad.back.setVisible(true);
        dPad.right.setVisible(false);
        dPad.left.setVisible(false);
        dPad.up.setVisible(false);
        dPad.down.setVisible(false);
    }
}
