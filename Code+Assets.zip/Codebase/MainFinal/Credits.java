package MainFinal;

import javax.swing.*;

public class Credits{
    JPanel panel;
    JLayeredPane layer;
    JLabel background;
    static JLabel c1, c2;

    public static final int SCREEN_WIDTH = 1850, SCREEN_HEIGHT = 900;
    public static final String btnpath = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\Buttons\\";

    String credSFX = Game.Directory+":\\LeapFrog\\GameAssets\\SFX\\bump.mp3";
    String addressBackground = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\Credits\\Credits.jpg";
    String addressTrans = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\Background\\transition.png";
    String cloud1 = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\Credits\\cloud1.png";
    String cloud2 = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\Credits\\cloud2.png";


/////////     Functions
//////
///   public void Background()
//    public void scenes()
//    public void panel()
///
////  public static class animationCloud
/////


    Credits(){
        Background();
        scenes();
        panel();
    }
    public void Background() {
        background = new JLabel();
        background.setIcon(new ImageIcon(addressBackground));
        background.setBounds(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
        background.setVisible(true);

        c1 = new JLabel();
        c1.setIcon(new ImageIcon(cloud1));
        c1.setBounds(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
        c1.setVisible(true);

        c2 = new JLabel();
        c2.setIcon(new ImageIcon(cloud2));
        c2.setBounds(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
        c2.setVisible(true);

    }
    public void scenes() {
        layer = new JLayeredPane();
        layer.setBounds(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
        layer.add(background, new Integer(1));

        layer.add(c1, new Integer(2));
        layer.add(c2, new Integer(2));
    }
    public void panel() {
        panel = new JPanel();
        panel.setBounds(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
        panel.setLayout(null);
        panel.add(layer);
        panel.setVisible(true);
    }

    //Animating the clouds present in the background (horizontal displacement)
    public static class animationCloud extends Thread {
        public void run() {
            try {
                setPriority(1);

                for (int j = 0; j < 100000; j++) {
                    for (int i = 0; i < 60; i++) {
                        sleep(50);
                        c1.setLocation(c1.getX() + 1, c1.getY()); //right
                        c2.setLocation(c2.getX() - 1, c2.getY()); //right
                        //sleep(300);
                    }
                    for (int i = 0; i < 60; i++) {
                        sleep(50);
                        c1.setLocation(c1.getX() - 1, c1.getY()); //left
                        c2.setLocation(c2.getX() + 1, c2.getY()); //left
                        //sleep(300);
                    }
                }
            } catch (InterruptedException f) {
                System.out.println(f);
            }
        }
    }
}