package MainFinal;

import javax.swing.*;

public class Frog {

    JLabel frog;

    Frog(){
        character();
    }

    public void character(){
        frog=new JLabel();
        frog.setBounds(0,0,200,170);
        frog.setIcon(new ImageIcon(Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\Frog\\frogD.png"));
        frog.setOpaque(false);
        frog.setVisible(true);
    }

}