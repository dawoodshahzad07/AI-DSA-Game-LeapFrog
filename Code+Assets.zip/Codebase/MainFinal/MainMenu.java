package MainFinal;

import javax.swing.*;
//import jaco.mp3.player.MP3Player;

import java.io.File;

public class MainMenu{
    JPanel panel;
    JLayeredPane layer;
    JLabel background;
    JButton start,credit, exit;
    animation a1=new animation();

    public static final int SCREEN_WIDTH = 1850, SCREEN_HEIGHT = 900;
    public static final String btnpath = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\Buttons\\";

    String sfxBtn = Game.Directory+":\\LeapFrog\\GameAssets\\SFX\\bullet.mp3";
    String addressBackground0 = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\MainMenu\\Main.jpg";
    String addressBackground = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\MainMenu\\Frames\\1.jpg";
    String addressBackground1 = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\MainMenu\\Frames\\2.jpg";
    String addressBackground2 = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\MainMenu\\Frames\\3.jpg";
    String addressBackground3 = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\MainMenu\\Frames\\4.jpg";
    String addressBackground4 = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\MainMenu\\Frames\\5.jpg";
    String addressBackground5 = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\MainMenu\\Frames\\6.jpg";
    String addressBackground6 = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\MainMenu\\Frames\\7.jpg";
    String addressBackground7 = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\MainMenu\\Frames\\8.jpg";
    String addressBackground8 = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\MainMenu\\Frames\\9.jpg";
    String addressBackground9 = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\MainMenu\\Frames\\10.jpg";
    String addressBackground10 = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\MainMenu\\Frames\\11.jpg";
    String addressBackground11 = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\MainMenu\\Frames\\12.jpg";
    String addressBackground12 = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\MainMenu\\Frames\\13.jpg";
    String addressBackground13 = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\MainMenu\\Frames\\14.jpg";
    String addressBackground14 = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\MainMenu\\Frames\\15.jpg";
    String addressBackground15 = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\MainMenu\\Frames\\16.jpg";
    String StartButton = btnpath + "Start1-1.png";
    String StartButtonHover = btnpath + "Start1-2.png";
    String StartButtonPress = btnpath + "Start1-3.png";

    String CreditsButton = btnpath + "Credits1-1.png";
    String CreditsButtonHover = btnpath + "Credits1-2.png";
    String CreditsButtonPress = btnpath + "Credits1-3.png";

    String ExitButton = btnpath + "Exit1-1.png";
    String ExitButtonHover = btnpath + "Exit1-2.png";
    String ExitButtonPress = btnpath + "Exit1-2.png";




    MainMenu(){
        Background();
        scenes();
        panel();
        a1.start();
    }
    public void Background() {
        background = new JLabel();
        background.setIcon(new ImageIcon(addressBackground));
        background.setBounds(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
        background.setVisible(true);

        start = new JButton();
        start.setIcon(new ImageIcon(StartButton));
        start.setBounds(780, 330, 310, 100);
        start.setText("Start Game");
        start.setBorder(null);
        start.setContentAreaFilled(false);
        start.setOpaque(false);
        start.setVisible(true);
        start.setRolloverIcon(new ImageIcon(StartButtonHover));
        start.setSelectedIcon(new ImageIcon(StartButtonPress));

        credit = new JButton();
        credit.setIcon(new ImageIcon(CreditsButton));
        credit.setBounds(780, 480, 310, 100);
        credit.setText("Credits");
        credit.setBorder(null);
        credit.setContentAreaFilled(false);
        credit.setOpaque(false);
        credit.setVisible(true);
        credit.setRolloverIcon(new ImageIcon(CreditsButtonHover));
        credit.setSelectedIcon(new ImageIcon(CreditsButtonPress));

        exit = new JButton();
        exit.setIcon(new ImageIcon(ExitButton));
        exit.setBounds(780, 630, 310, 100);
        exit.setText("Exit");
        exit.setBorder(null);
        exit.setContentAreaFilled(false);
        exit.setOpaque(false);
        exit.setVisible(true);
        exit.setRolloverIcon(new ImageIcon(ExitButtonHover));
        exit.setSelectedIcon(new ImageIcon(ExitButtonPress));
    }
    public void scenes() {
        layer = new JLayeredPane();
        layer.setBounds(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
        layer.add(background, new Integer(1));
        layer.add(start, new Integer(2));
        layer.add(credit, new Integer(2));
        layer.add(exit, new Integer(2));
    }
    public void panel() {
        panel = new JPanel();
        panel.setBounds(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
        panel.setLayout(null);
        panel.add(layer);
        panel.setVisible(true);
    }

    public JLabel getLabel(){
        return this.background;
    }

    public void Sound() {
        MP3Player sfx = new MP3Player(new File(sfxBtn));
        sfx.play();
    }
    class animation extends Thread {
        public void run() {
            try {

                while(getLabel().isVisible()) {
                        background.setIcon(new ImageIcon(addressBackground0));
                        sleep(150);
                        background.setIcon(new ImageIcon(addressBackground));
                        sleep(150);
                        background.setIcon(new ImageIcon(addressBackground1));
                        sleep(130);
                        background.setIcon(new ImageIcon(addressBackground2));
                        sleep(130);
                        background.setIcon(new ImageIcon(addressBackground3));
                        sleep(130);
                        background.setIcon(new ImageIcon(addressBackground4));
                        sleep(130);
                        background.setIcon(new ImageIcon(addressBackground5));
                        sleep(100);
                        background.setIcon(new ImageIcon(addressBackground6));
                        sleep(100);
                        background.setIcon(new ImageIcon(addressBackground7));
                        sleep(100);
                        background.setIcon(new ImageIcon(addressBackground8));
                        sleep(100);
                        background.setIcon(new ImageIcon(addressBackground9));
                        sleep(100);
                        background.setIcon(new ImageIcon(addressBackground10));
                        sleep(100);
                        background.setIcon(new ImageIcon(addressBackground11));
                        sleep(100);
                        background.setIcon(new ImageIcon(addressBackground12));
                        sleep(140);
                        background.setIcon(new ImageIcon(addressBackground13));
                        sleep(180);
                        background.setIcon(new ImageIcon(addressBackground14));
                        sleep(220);
                        background.setIcon(new ImageIcon(addressBackground15));
                        sleep(300);
                }


            } catch (InterruptedException f) {
                System.out.println(f.toString());
            }

        }
    }
}