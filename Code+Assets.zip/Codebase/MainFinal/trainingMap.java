package MainFinal;

import javax.swing.*;

public class trainingMap {

    JPanel jPanel;
    JLayeredPane layer;
    JLabel map1, goal;
    JLabel lilyPads[][];
    Frog frog=new Frog();
    String b_address= Game.Directory+ ":\\LeapFrog\\GameAssets\\GFX\\Background\\LevelT.png";
    String gWon_address= Game.Directory+ ":\\LeapFrog\\GameAssets\\GFX\\Levels\\cleared.png";
    String goalAddr= Game.Directory+ ":\\LeapFrog\\GameAssets\\GFX\\Blocks\\coin.gif";

    Movement movement=new Movement();
    DPad dPad=new DPad();

    public static final int SCREEN_WIDTH=1600,SCREEN_HEIGHT=900;
    public int moves = 99, score = 999;

    int Ogrid1[][] = {{1,1, 1, 1, 1, 1, 1, 1},
            {1,1, 1, 1, 0, 1, 1, 1},
            {1,1, 1, 0, 0, 0, 1, 1},
            {1,0, 1, 0, 0, 1, 1, 1},
            {1,1, 0, 0, 1, 1, 1, 1},
            {1,1, 1, 0, 0, 1, 1, 1}
    };
    trainingMap(){
        movement.m2d.Ogrid=this.Ogrid1;
        movement.totalMoves = moves;

        labelMap1();

        DPadInitialize();
        jLayer();
        jPanel();

    }

    public void labelMap1(){
        map1=new JLabel();
        map1.setBounds(0,0,SCREEN_WIDTH,SCREEN_HEIGHT);
        map1.setIcon(new ImageIcon(b_address));
        map1.setVisible(true);

        goal=new JLabel();
        goal.setBounds(830,80,250,250);
        goal.setIcon(new ImageIcon(goalAddr));
        goal.setVisible(true);
    }
    public void jPanel(){
        jPanel=new JPanel();
        jPanel.setBounds(0,0,SCREEN_WIDTH,SCREEN_HEIGHT);
        jPanel.setLayout(null);
        jPanel.add(layer);
        jPanel.setVisible(false);
    }
    public void jLayer(){
        layer=new JLayeredPane();
        layer.setBounds(0,0,SCREEN_WIDTH,SCREEN_HEIGHT);
        layer.add(map1,new Integer(1));
        layer.add(frog.frog,new Integer(8));
        lilySpawn(layer);

        layer.add(goal,new Integer(7));

        layer.add(dPad.scoreDisplay,new Integer(5));
        layer.add(dPad.moveDisplay,new Integer(5));

        layer.add(dPad.back,new Integer(5));
        layer.add(dPad.up,new Integer(6));
        layer.add(dPad.down,new Integer(6));
        layer.add(dPad.right,new Integer(6));
        layer.add(dPad.left,new Integer(6));
    }

    public void lilySpawn(JLayeredPane layer) {

        lilyPads = new JLabel[Map_2D.num_Horizontal_boxes][Map_2D.num_Vertical_boxes+2];

        for (int i = 0; i < Map_2D.num_Vertical_boxes; i++) {

            for (int j = 0; j < Map_2D.num_Horizontal_boxes; j++) {

                try {
                    if (this.Ogrid1[i][j] == 1)
                        continue;
                    else{
                        JLabel pad = new JLabel();


                        pad.setIcon(new ImageIcon(Game.Directory + ":\\LeapFrog\\GameAssets\\GFX\\Blocks\\L1d.png"));
                        pad.setBounds(j * 200, i * (150 - 2), 200, 156);
                        pad.setVisible(true);
                        lilyPads[i][j] = pad;
                        layer.add(pad, new Integer(3));

                    }
                }catch(Exception e){

                }
            }
        }
    }

    public void enablePads(int fPosX, int fPosY){

        lilyPads[fPosX][fPosY].setIcon(new ImageIcon(Game.Directory + ":\\LeapFrog\\GameAssets\\GFX\\Blocks\\L1e.png"));
    }

    public void clearPads(){

        for (int i = 0; i < Map_2D.num_Vertical_boxes; i++) {
            for (int j = 0; j < Map_2D.num_Horizontal_boxes; j++)
                try {
                    lilyPads[i][j].setIcon(new ImageIcon(Game.Directory + ":\\LeapFrog\\GameAssets\\GFX\\Blocks\\L1d.png"));
                }catch(Exception e){}
        }
    }

    public void initMoves(Movement movement){
        movement.totalMoves = moves;
        movement.totalScore = score;
    }

    void DPadInitialize(){
        dPad.back.setVisible(true);
        dPad.right.setVisible(false);
        dPad.left.setVisible(false);
        dPad.up.setVisible(false);
        dPad.down.setVisible(false);
    }


}
