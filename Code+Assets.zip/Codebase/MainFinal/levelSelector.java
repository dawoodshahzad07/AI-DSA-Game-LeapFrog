package MainFinal;

import javax.swing.*;
import java.io.File;
import java.util.Scanner;

public class levelSelector {

    JPanel jPanel;
    JLayeredPane layer;
    JLabel map1;
    Frog frog=new Frog();
    String b_address= Game.Directory+ ":\\LeapFrog\\GameAssets\\GFX\\Background\\LevelSS.jpg";
    String gWon_address= Game.Directory+ ":\\LeapFrog\\GameAssets\\GFX\\Levels\\cleared.png";

    Movement movement=new Movement();
    DPad dPad=new DPad();

    public static final int SCREEN_WIDTH=1850,SCREEN_HEIGHT=900;
    int loadSave = -1, moves = 0;

    int Ogrid[][] ={{1, 1, 1, 1, 1, 1, 1, 1},
                    {1, 1, 1, 1, 1, 1, 1, 1},
                    {1, 1, 1, 1, 1, 1, 1, 1},
                    {1, 1, 1, 1, 1, 1, 1, 1},
                    {1, 1, 1, 1, 1, 1, 1, 1},
                    {1, 1, 1, 0, 1, 1, 1, 1}
    };
    levelSelector(){

        frog.frog.setIcon(new ImageIcon(Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\Interactive\\ArrowL.png"));
        labelMap1();
        //loadSave();
        unlockLevels();
        movement.m2d.Ogrid=this.Ogrid;

        DPadInitialize();
        jLayer();
        jPanel();

    }


    public void labelMap1(){
        map1=new JLabel();
        map1.setBounds(0,0,SCREEN_WIDTH,SCREEN_HEIGHT);
        map1.setIcon(new ImageIcon(b_address));
        map1.setVisible(true);
    }
    public void jPanel(){
        jPanel=new JPanel();
        jPanel.setBounds(0,0,SCREEN_WIDTH,SCREEN_HEIGHT);
        jPanel.setLayout(null);
        jPanel.add(layer);
        jPanel.setVisible(false);
    }
    public void jLayer(){
        layer=new JLayeredPane();
        layer.setBounds(0,0,SCREEN_WIDTH,SCREEN_HEIGHT);
        layer.add(map1,new Integer(1));
        layer.add(frog.frog,new Integer(2));

        layer.add(dPad.scoreDisplay,new Integer(5));
        layer.add(dPad.moveDisplay,new Integer(5));

        layer.add(dPad.back,new Integer(5));
        layer.add(dPad.up,new Integer(6));
        layer.add(dPad.down,new Integer(6));
        layer.add(dPad.right,new Integer(6));
        layer.add(dPad.left,new Integer(6));
    }
    void DPadInitialize(){
        dPad.back.setVisible(true);
        dPad.right.setVisible(false);
        dPad.left.setVisible(false);
        dPad.up.setVisible(false);
        dPad.down.setVisible(false);
    }

    void unlockLevels(){

        loadSave();

        //Training
        if(loadSave == 0){
            this.Ogrid[5][3] = 0;
            this.Ogrid[5][4] = 0;
        }
        //L1
        else if (loadSave == 1){
            this.Ogrid[5][3] = 0;
            this.Ogrid[5][4] = 0;

            this.Ogrid[4][4] = 0;

            this.Ogrid[3][4] = 0;
        }
        //L2
        else if (loadSave == 2){
            this.Ogrid[5][3] = 0;
            this.Ogrid[5][4] = 0;

            this.Ogrid[4][4] = 0;

            this.Ogrid[3][4] = 0;
            this.Ogrid[3][3] = 0;
        }

    }

    public void initMoves(Movement movement){
        movement.totalMoves = moves;
    }
    void loadSave(){

        //Reading Saves
        Scanner read = null;
        try {
            read = new Scanner(new File(Game.Directory+":\\LeapFrog\\GameAssets\\Other\\Saves.txt"));
            loadSave = Integer.parseInt(read.nextLine());
            System.out.println("Loaded upto stage: " +loadSave);

        } catch (Exception e) {
            System.out.println(e);
            loadSave = -1;
        }
    }
}
