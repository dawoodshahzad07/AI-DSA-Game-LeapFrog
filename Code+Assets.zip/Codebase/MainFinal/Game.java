package MainFinal;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Stack;

//import jaco.mp3.player.MP3Player;
import static java.lang.Thread.sleep;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

class Levels{

    static final int LEVEL_SELECTOR = -1;
    static final int LEVEL_TRAINING = 0;
    static final int LEVEL_1 = 1;
    static final int LEVEL_2 = 2;
    static final int LEVEL_3 = 3;

    static final int CREDITS = 5;

  }


public class Game extends JFrame implements KeyListener, ActionListener {
    static String Directory = "D";
    public static final int SCREEN_WIDTH = 1860,SCREEN_HEIGHT = 935;

    JLayeredPane layer;

    MainFinal.levelSelector levelSelector=new levelSelector();
    MainFinal.trainingMap trainingMap=new trainingMap();
    Map1 map1=new Map1();
    Map2 map2=new Map2();
    MainMenu mainMenu=new MainMenu();
    Credits credits=new Credits();
    AStarSearch astar = new AStarSearch();
    Credits.animationCloud a1 = new Credits.animationCloud();
    transition trans = new transition();

    int stage=-2;
    boolean keyPressed = false;

/////////     Functions
//////
///   public void layer()  //different panels are being added in the layeredpane
//    public void jFrame() //layer is being added in this function and the size of the frame is
//    public void actionPerformed(ActionEvent e)
//    public void keyPressed(KeyEvent e)
//    public void keyReleased(KeyEvent e)
//    public void Switch()
//    public void Spawn(int stage)
//    public void glowPath(JButton[][] lilyPads, Stack<Cell> path)
//    public void showCredits()
///   public void endCredits()
////  public void writeSave(int stage)
/////

    Game(){

        layer();
        Spawn(stage);
        Switch();
        jFrame();
        a1.start();
    }
    public void layer(){
        layer=new JLayeredPane();
        layer.setBounds(0,0,SCREEN_WIDTH,SCREEN_HEIGHT);
        layer.add(mainMenu.panel, new Integer(1));
        layer.add(map1.jPanel, new Integer(1));
        layer.add(map2.jPanel, new Integer(1));
        layer.add(trainingMap.jPanel, new Integer(1));
        layer.add(levelSelector.jPanel, new Integer(1));
        layer.add(credits.panel, new Integer(2));
        layer.add(trans.background, new Integer(3));
        credits.panel.setVisible(false);
    }
    public void jFrame(){

        this.setIconImage(new ImageIcon(Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\Interactive\\icon.png").getImage());
        this.setTitle("LeapFrog 1: The Leapening");
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBackground(Color.BLACK);
        this.setSize(SCREEN_WIDTH, SCREEN_HEIGHT);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.add(layer);
        this.addKeyListener(this);
        this.setVisible(true);
    }
    @Override

    //Checaks the buttons in the main menu
    public void actionPerformed(ActionEvent e) {
        transitionloop t1 = new transitionloop();
        t1.start();
        mainMenu.Sound();
         if (e.getSource() == mainMenu.start) { //When start button is pressed
            System.out.println("a");
            mainMenu.start.setFocusable(false);
            this.requestFocus(true);
            stage=-1;

            //Switch();
        }
        else if (e.getSource() == mainMenu.exit) { //When exit button is pressed
            try {
                sleep(500);
                System.exit(0);
            } catch (InterruptedException ex) {
                throw new RuntimeException(ex);
            }
        }
        else if (e.getSource() == mainMenu.credit) { //When credits button is pressed
            //stage = 5;
            //Switch();
            //showCredits();
             credit c = new credit();
             c.start();
        }

    }
    @Override
    public void keyTyped(KeyEvent e) {
    }
    @Override
    //Handls all key presses
    public void keyPressed(KeyEvent e) {
        int keyCheck=e.getKeyCode();
        Stack<Cell> path;
        //MP3Player bumpSFX = new MP3Player(new File(Movement.bumpsfx));
        System.out.println(map1.frog.frog.getX()+" | "+map1.frog.frog.getY());

        //Unglow hint path if any key is pressed
        if (keyCheck != KeyEvent.VK_9){
            map1.unglowPath();
            map2.unglowPath();
        }

        //reject duplicate key presses
        if(!keyPressed) {
            keyPressed = true;

            switch (keyCheck) {

                case 87:
                case KeyEvent.VK_UP:
                    //Movement Handlers for each level
                    if(stage==Levels.LEVEL_SELECTOR){
                        //I there is no obstacle, proceed on the next block
                        if (levelSelector.movement.canMove("UP")) {
                            levelSelector.movement.moveUp(levelSelector.frog.frog);
                        }
                        //If an obstacle is reached, play bump sfx
                        else
                            bumpSFX.play();
                        levelSelector.frog.frog.setIcon(new ImageIcon(Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\Interactive\\ArrowU.png"));
                    }
                    else if(stage==Levels.LEVEL_TRAINING){
                        if (trainingMap.movement.canMove("UP")) {
                            trainingMap.movement.moveUp(trainingMap.frog.frog);
                        }
                        //else
                          //  bumpSFX.play();
                    }
                    else if(stage==Levels.LEVEL_1) {
                        if (map1.movement.canMove("UP")) {
                            map1.movement.moveUp(map1.frog.frog);
                        }
                        //else
                          //  bumpSFX.play();
                    }
                    else if(stage==Levels.LEVEL_2) {
                        if (map2.movement.canMove("UP"))
                            map2.movement.moveUp(map2.frog.frog);
                        //else
                          //  bumpSFX.play();
                    }

                    break;

                case 83:
                case KeyEvent.VK_DOWN:
                    if(stage==Levels.LEVEL_SELECTOR){
                        if (levelSelector.movement.canMove("DOWN")) {
                            levelSelector.movement.moveDown(levelSelector.frog.frog);
                        }
                        //else
                          //  bumpSFX.play();
                        levelSelector.frog.frog.setIcon(new ImageIcon(Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\Interactive\\ArrowD.png"));
                    }
                    else if(stage==Levels.LEVEL_TRAINING){
                        if (trainingMap.movement.canMove("DOWN")) {
                            trainingMap.movement.moveDown(trainingMap.frog.frog);
                        }
                        //else
                          //  bumpSFX.play();
                    }
                    else if(stage==Levels.LEVEL_1) {
                        if (map1.movement.canMove("DOWN")) {
                            map1.movement.moveDown(map1.frog.frog);
                        }
                        //else
                          //  bumpSFX.play();
                    }
                    else if(stage==Levels.LEVEL_2) {
                        if (map2.movement.canMove("DOWN")) {
                            map2.movement.moveDown(map2.frog.frog);
                        }
                        //else
                          //  bumpSFX.play();
                    }
                    break;

                case 68:
                case KeyEvent.VK_RIGHT:
                    if(stage==Levels.LEVEL_SELECTOR){
                        if (levelSelector.movement.canMove("RIGHT")) {
                            levelSelector.movement.moveRight(levelSelector.frog.frog);
                        }
                        //else
                          //  bumpSFX.play();
                        levelSelector.frog.frog.setIcon(new ImageIcon(Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\Interactive\\ArrowR.png"));
                    }
                    else if(stage==0){
                        if (trainingMap.movement.canMove("RIGHT")) {
                            trainingMap.movement.moveRight(trainingMap.frog.frog);
                        }
                        //else
                          //  bumpSFX.play();
                    }
                    else if(stage==Levels.LEVEL_1) {
                        if (map1.movement.canMove("RIGHT")) {
                            map1.movement.moveRight(map1.frog.frog);
                        }
                        //else
                            //bumpSFX.play();
                    }
                    else if(stage==Levels.LEVEL_2) {
                        if (map2.movement.canMove("RIGHT")) {
                            map2.movement.moveRight(map2.frog.frog);
                        }
                        //else
                          //  bumpSFX.play();
                    }

                    break;
                //LEFT
                case 65:
                case KeyEvent.VK_LEFT:
                    if(stage==Levels.LEVEL_SELECTOR){
                        if (levelSelector.movement.canMove("LEFT")) {
                            levelSelector.movement.moveLeft(levelSelector.frog.frog);
                        }
                        else
                            //bumpSFX.play();
                        levelSelector.frog.frog.setIcon(new ImageIcon(Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\Interactive\\ArrowL.png"));
                    }
                    else if(stage==Levels.LEVEL_TRAINING){
                        if (trainingMap.movement.canMove("LEFT")) {
                            trainingMap.movement.moveLeft(trainingMap.frog.frog);
                        }
                        //else
                            //bumpSFX.play();

                    }
                    else if(stage==Levels.LEVEL_1) {
                        if (map1.movement.canMove("LEFT")) {
                            map1.movement.moveLeft(map1.frog.frog);
                        }
                        //else
                            //bumpSFX.play();
                    }
                    else if(stage==Levels.LEVEL_2) {
                        if (map2.movement.canMove("LEFT")) {
                            map2.movement.moveLeft(map2.frog.frog);
                        }
                        //else
                          //  bumpSFX.play();
                    }
                    break;
                case 10: //ENTER KEY
                    if(stage==Levels.LEVEL_SELECTOR){
                        if(levelSelector.movement.fPosX == 5 && levelSelector.movement.fPosY == 3){
                            stage=Levels.LEVEL_TRAINING;
                            transitionloop t1 = new transitionloop();
                            t1.start();
                            //Switch();
                        }
                        else if(levelSelector.movement.fPosX == 5 && levelSelector.movement.fPosY == 4){
                            stage=Levels.LEVEL_1;
                            transitionloop t1 = new transitionloop();
                            t1.start();
                            //Switch();
                        }
                        else if(levelSelector.movement.fPosX == 3 && levelSelector.movement.fPosY == 4){
                            stage=Levels.LEVEL_2;
                            transitionloop t1 = new transitionloop();
                            t1.start();
                            //Switch();
                        }
                        else if(levelSelector.movement.fPosX == 3 && levelSelector.movement.fPosY == 3){
                            stage=Levels.LEVEL_3;
                            transitionloop t1 = new transitionloop();
                            t1.start();
                            //Switch();
                        }
                    }
                    break;
                case KeyEvent.VK_9: //9 KEY
                    //Pathfinding
                    //  MP3Player hintSFX = new MP3Player(new File(Movement.hintsfx));

                    if(stage==Levels.LEVEL_1) {
                        //find new path
                        path = astar.calcPath(map1.Ogrid1, map1.movement.fPosX, map1.movement.fPosY, map1.goalX, map1.goalY);
                      //  hintSFX.play(); //play sound
                        //glow the found path
                        map1.glowPath(path);
                        //print path coords, logging purposes
                        map1.movement.showPath(path);
                    }
                    else if(stage==Levels.LEVEL_2) {
                        path = astar.calcPath(map2.Ogrid1, map2.movement.fPosX, map2.movement.fPosY, map2.goalX, map2.goalY);
                      //  hintSFX.play();
                        map2.glowPath(path);
                        map2.movement.showPath(path);
                    }
                    break;

                case KeyEvent.VK_0:
                    //print path coords
                    if(stage==1)
                     map1.movement.m2d.showPGrid();
                    else if (stage==2)
                        map2.movement.m2d.showPGrid();
                    break;
            }

            //Enable the blocks that are visited
            if(stage==0)
                trainingMap.enablePads(trainingMap.movement.fPosX, trainingMap.movement.fPosY);
            else if(stage==1)
                map1.enablePads(map1.movement.fPosX, map1.movement.fPosY);
            else if(stage==2)
                map2.enablePads(map2.movement.fPosX, map2.movement.fPosY);
        }
    }
    @Override
    public void keyReleased(KeyEvent e) {
        //when a key  is released
        int keyCheck=e.getKeyCode();
        keyPressed =false;

        System.out.println("xPos: " + (map1.movement.fPosX) + " | " + " yPos: "+ (map1.movement.fPosY));
        System.out.println("Moves Left: " + (map1.movement.totalMoves));


        //update DPAD after each key release
        //also update the moves and score

        if(stage==Levels.LEVEL_SELECTOR) {
            levelSelector.dPad.DPadUpdate(levelSelector.movement);
            levelSelector.dPad.levelSelectHUD(levelSelector.movement.fPosX, levelSelector.movement.fPosY);
            //levelSelector.dPad.updateHUD(900, 1);
        }
        else if(stage==Levels.LEVEL_TRAINING){

            //If a level is completed
            //write a save file for the level
            //then spawn back to level selector
            if(trainingMap.movement.hasWon(trainingMap.frog.frog,stage)){

                writeSave(stage);
                stage=Levels.LEVEL_SELECTOR;
                Spawn(stage);
                transitionloop t1 = new transitionloop();
                t1.start();
                //Switch();
            }

            trainingMap.dPad.DPadUpdate(trainingMap.movement);
            trainingMap.dPad.updateHUD(trainingMap.movement.totalScore, trainingMap.movement.totalMoves);
        }
        else if(stage==Levels.LEVEL_1) {

            if(map1.movement.hasWon(map1.frog.frog, stage)){
                writeSave(stage);
                stage=Levels.LEVEL_SELECTOR;
                Spawn(stage);
                transitionloop t1 = new transitionloop();
                t1.start();
                //Switch();
            }
            map1.dPad.DPadUpdate(map1.movement);
            map1.dPad.updateHUD(map1.movement.totalScore, map1.movement.totalMoves);
        }
        else if(stage==Levels.LEVEL_2) {
            //map2.enablePads(map2.movement.fPosX, map2.movement.fPosY);
            if(map2.movement.hasWon(map2.frog.frog, stage)){
                writeSave(stage);
                stage=Levels.LEVEL_SELECTOR;
                Spawn(stage);
                transitionloop t1 = new transitionloop();
                t1.start();
                //Switch();
            }
            map2.dPad.DPadUpdate(map2.movement);
            map2.dPad.updateHUD(map2.movement.totalScore, map2.movement.totalMoves);
        }

        switch (keyCheck) {
            //UP
            case 87:
            case KeyEvent.VK_UP:
                //DOWN
            case 83:
            case KeyEvent.VK_DOWN:

                //RIGHT
            case 68:
            case KeyEvent.VK_RIGHT:

                //LEFT
            case 65:
            case KeyEvent.VK_LEFT:

                keyPressed =false;
                break;
        }

    }
    public void Switch(){

        //Switches the sceens, Level changes
        if(stage==-2){
            mainMenu.panel.setVisible(true);
            levelSelector.jPanel.setVisible(false);
            levelSelector.unlockLevels();
            map1.jPanel.setVisible(false);
            trainingMap.jPanel.setVisible(false);
            mainMenu.start.addActionListener(this);
            mainMenu.credit.addActionListener(this);
            mainMenu.exit.addActionListener(this);
        }
        else if(stage==Levels.LEVEL_SELECTOR){
            mainMenu.panel.setVisible(false);
            levelSelector.initMoves(levelSelector.movement);
            levelSelector.jPanel.setVisible(true);
            levelSelector.unlockLevels();
            map1.jPanel.setVisible(false);
            map2.jPanel.setVisible(false);
            trainingMap.jPanel.setVisible(false);
            Spawn(stage);
        }
        else if(stage==Levels.LEVEL_TRAINING){
            mainMenu.panel.setVisible(false);
            levelSelector.jPanel.setVisible(false);
            levelSelector.unlockLevels();
            map1.jPanel.setVisible(false);
            trainingMap.clearPads();
            trainingMap.initMoves(trainingMap.movement);
            trainingMap.jPanel.setVisible(true);
            Spawn(stage);
        }
        else if(stage==Levels.LEVEL_1){
            mainMenu.panel.setVisible(false);
            levelSelector.jPanel.setVisible(false);
            levelSelector.unlockLevels();
            map1.clearPads();
            map1.initMoves(map1.movement);
            map1.jPanel.setVisible(true);
            trainingMap.jPanel.setVisible(false);
            Spawn(stage);
        }
        else if(stage==Levels.LEVEL_2){
            mainMenu.panel.setVisible(false);
            levelSelector.jPanel.setVisible(false);
            levelSelector.unlockLevels();
            map2.initMoves(map2.movement);
            map2.clearPads();
            map1.jPanel.setVisible(false);
            trainingMap.jPanel.setVisible(false);
            map2.jPanel.setVisible(true);
            Spawn(stage);
        }
        else if(stage==Levels.CREDITS){
            mainMenu.panel.setVisible(false);
            levelSelector.jPanel.setVisible(false);
            map1.jPanel.setVisible(false);
            trainingMap.jPanel.setVisible(false);
            credits.panel.setVisible(true);
        }

    }
    public void Spawn(int stage){

        //Spawns the frog at different spawn points for different levels
        if(stage==Levels.LEVEL_SELECTOR) {
            levelSelector.movement.fPosX = 5;
            levelSelector.movement.fPosY = 3;
            levelSelector.frog.frog.setLocation((levelSelector.movement.fPosY * 200), 650);
            levelSelector.movement.m2d.Pgrid[levelSelector.movement.fPosX][levelSelector.movement.fPosY] = 1;
        }
        if(stage==Levels.LEVEL_TRAINING){
            trainingMap.movement.fPosX = 5;
            trainingMap.movement.fPosY = 4;
            trainingMap.frog.frog.setLocation((trainingMap.movement.fPosY *200),750);
            trainingMap.movement.m2d.Pgrid[trainingMap.movement.fPosX][trainingMap.movement.fPosY] = 1;

        }
        if(stage==Levels.LEVEL_1) {
            map1.movement.fPosX = 5;
            map1.movement.fPosY = 3;
            map1.frog.frog.setLocation((map1.movement.fPosY * 200), 750);
            map1.movement.m2d.Pgrid[map1.movement.fPosX][map1.movement.fPosY] = 1;
        }
        if(stage==Levels.LEVEL_2) {
            map2.movement.fPosX = 3;
            map2.movement.fPosY = 0;
            map2.frog.frog.setLocation((map2.movement.fPosY * 200), 450);
            map2.movement.m2d.Pgrid[map2.movement.fPosX][map2.movement.fPosY] = 1;
        }
    }

    //the credits screen is to be shown for 10 seconds after the button is pressed, then switch to main menu
    public class credit extends Thread {
        public void run() {
            try {
                setPriority(1);
                showCredits();
                sleep(10000);
                endCredits();
            } catch (InterruptedException f) {
                System.out.println(f);
            }
        }
    }

    //Setup credits scene
    public void showCredits(){

        mainMenu.panel.setVisible(false);
        levelSelector.jPanel.setVisible(false);
        map1.jPanel.setVisible(false);
        trainingMap.jPanel.setVisible(false);
        credits.panel.setVisible(true);
    }

    //End the credits scene
    public void endCredits(){

        credits.panel.setVisible(false);
        mainMenu.panel.setVisible(true);
    }


    //Write a save file
    public void writeSave(int stage){

        //Reading Saves
        Scanner read = null;
        int loadSave;

        try {
            //Read the integer stored i the file
            read = new Scanner(new File(Game.Directory+":\\LeapFrog\\GameAssets\\Other\\Saves.txt"));
            loadSave = Integer.parseInt(read.nextLine());

        } catch (Exception e) {

            //If no save file is found, set level to training level
            System.out.println(e);
            loadSave = -1;
        }

        //Only save if its a new level
        if(stage > loadSave) {

            PrintWriter write = null;
            try {
                write = new PrintWriter(Directory + ":\\LeapFrog\\GameAssets\\Other\\Saves.txt");
                write.println(stage);
                write.close();
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            }
        }

    }

    //Transitions between screens
    class transitionloop extends Thread {
        public void run() {
            trans.background.setVisible(true);
            try {
                System.out.println("11");
                setPriority(1);
                for(int i=0;i<185;i++) {
                    System.out.println("a");
                    trans.background.setLocation(trans.background.getX()-10,trans.background.getY());
                    sleep(1);
                }
                Switch();
                for(int i=0;i<300;i++) {
                    System.out.println("b");
                    trans.background.setLocation(trans.background.getX()+10,trans.background.getY());
                    sleep(1);
                }

                trans.background.setBounds(0, 0, 1850*2, 900);
                trans.background.setVisible(false);

            } catch (InterruptedException f) {
                System.out.println(f.toString());
            }

        }
    }

}
