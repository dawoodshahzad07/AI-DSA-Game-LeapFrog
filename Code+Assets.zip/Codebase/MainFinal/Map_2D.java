package MainFinal;

public class Map_2D {

    static final int num_Horizontal_boxes = 8, num_Vertical_boxes = 6;

    int[][] Pgrid = {{0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0}
    };

    int Ogrid[][] = {{1, 1, 1, 1, 1, 1, 1, 1},
            {1, 0, 0, 0, 0, 0, 0, 0},
            {1, 1, 0, 0, 0, 0, 0, 1},
            {1, 1, 0, 0, 0, 1, 0, 1},
            {1, 0, 0, 0, 0, 1, 1, 0},
            {1, 1, 1, 0, 1, 1, 1, 1}
    };

    boolean B_Pgrid[][] ={  {false, false, false, false, false, false, false},
                            {false, false, false, false, false, false, false},
                            {false, false, false, false, false, false, false},
                            {false, false, false, false, false, false, false},
                            {false, false, false, false, false, false, false},
                            {false, false, false, false, false, false, false},
    };

    boolean B_Ogrid[][] ={  {false, false, false, false, false, false, false},
                            {false, false, false, false, false, false, false},
                            {false, false, false, false, false, false, false},
                            {false, false, false, false, false, false, false},
                            {false, false, false, false, false, false, false},
                            {false, false, false, false, false, false, false},
    };

    void showPGrid() {

        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {

                System.out.print(Pgrid[i][j] + " ");
            }
            System.out.print("\n");
        }
    }
}
