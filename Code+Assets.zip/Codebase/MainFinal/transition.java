package MainFinal;

import javax.swing.*;
public class transition{
    JLabel background;

    public static final int SCREEN_WIDTH = 1850*2, SCREEN_HEIGHT = 900;

    String addressBackground = Game.Directory+":\\LeapFrog\\GameAssets\\GFX\\Background\\transition.png";


    transition(){
        Background();
    }
    public void Background() {
        background = new JLabel();
        background.setIcon(new ImageIcon(addressBackground));
        background.setBounds(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
        background.setOpaque(false);
        background.setVisible(false);
    }
}